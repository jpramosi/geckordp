PROFILE = "test_geckordp"
REMOTE_HOST = "localhost"
REMOTE_PORT = 6000
