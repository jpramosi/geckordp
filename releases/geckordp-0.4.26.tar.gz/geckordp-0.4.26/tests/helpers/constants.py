PROFILE0 = "test_geckordp0"
PROFILE1 = "test_geckordp1"
PROFILE2 = "test_geckordp2"
REMOTE_HOST = "localhost"
REMOTE_PORT = 6000
